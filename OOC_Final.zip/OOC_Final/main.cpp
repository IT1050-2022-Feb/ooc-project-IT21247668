// main.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include "Order.h"
#include "Payment.h"
#include "Admin.h"
#include "User.h"
#include "Resturent.h"
#include "Menu_card.h"
#include "Food.h"
#include "Deliverer.h"
#include "Feedback.h"
#include "Registered_customer"
#include<iostream>
#include <string>
#include<iomainip>
#define SIZE;
using namespace std;
int main()
{
	User* u1 = new User(001, "Harindu", "harindu12@gmail.com",
		"hriu52");//Overloaded constructor
		//User* u1 = new User(); //
	Default constructor
		Register_customer* r1 = new Register_customer(1,
			"No.56,Malkaduwawa,Kurunegala");//Overloaded constructor
			//RegisterCustomer* r1 = new RegisterCustomer(); 
			// Default constructor 
	Order* o1 = new Order(200, 05 / 04 / 2020, "Ready Deliver"); //Overloaded 
	constructor
		//Order* o1 = new Order(); // Default 
		constructor
		Deliver* d1 = new Deliver(1001, "Dilshan", "No.65,Ynathampalawa, 
			Kurunegala", "04 / 07 / 2022", 1520.00);//Overloaded constructor
			//Deliver* d1 = new Deliver(); 
			// Default constructor
			Admin * a1 = new Admin(52, "Ravin", 12001); //Overloaded constructor
			//Admin* a1 = new Admin(); // Default constructor
	Feedback * f1 = new Feedback(5001, "05/01/2022", "10.20 AM");//Overloaded 
	constructor
		Feedback * f2 = new Feedback(5002, "05/02/2022", "11.40 AM");
	//Feedback* f1 = new Feedback(); // Default 
	constructor
		Resturent * r1 = new Resturent("REG001", "Mr.kottu", "Mallawapitiya",
			"kavi23@gmail.com", "0785424165");//Overloaded constructor
			//Resturent* r1 = new Resturent();
			// Default constructor
	Menu_card * m1 = new Menu_card(150, "Chicken Kottu", 600.00);//Overloaded 
	constructor
		//MenuCard* m1 = new MenuCard(); // 
		Default constructor
		Payment * p1 = new Payment(10010, "Cash on Delivery");//Overloaded 
	constructor
		//Payment* p1 = new Payment(); // 
		Default constructor
		Food * fd1 = new Food(1001, "Pasta");//Overloaded constructor
	Food * fd2 = new Food(1001, "Pizza");
	Food * fd3 = new Food(1001, "Burger");
	//Food* f1 = new Food(); // Default constructor
	//---------------Method Call------------//
	u1->registeredtoSystem();
	r1->Login();
	r1->MakePayment();
	r1->SetFeedback();
	p1->setPayment();
	p1->setPaymentType();
	p1->displayPaymentMethod();
	p1->displayPaymentType();
	o1->createOrder();
	o1->updateOrder();
	o1->displayTotalPrice();
	//inheritance relationship
	d1->setAmount();
	d1->update();
	fd1->addFood();
	fd1->displayFoodItem();
	a1->generateReport();
	a1->displayDetails();
	f1->getDetails();
	f1->getFeedback();
	delete u1;
	delete r1;
	delete p1;
	delete o1;
	delete fd1;
	delete d1;
	delete a1;
	delete f1;
	return 0;
}
