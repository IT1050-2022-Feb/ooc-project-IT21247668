#include<iostream>
#include<string.h>
using namespace std;
class user
{
protected:
	int id;
	string name;
	string email;
	string password;
public:
	user();
	void setDetails(int uId, string uName, string umail, string uPass);
	void dispayUser();
};