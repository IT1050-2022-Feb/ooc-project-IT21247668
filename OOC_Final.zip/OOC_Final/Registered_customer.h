#include <iostream>
#include <string.h>
#include <user.h>
#include <payment>
#include <order.h>
using namespace std;
class registeredCustomer :public user
{
private:
	int customerId;
	string address;
	string name;
	double price;
	int quantity;
	Payment* paymemts[SIZE];
public:
	registeredCustomer();
	registeredCustomer(int cId, string cAddress, double cprice, int qty);
	void setprice(double cprice);
	void setquantity(int qty);
	double calPrice();
	~registeredCustomer();
};