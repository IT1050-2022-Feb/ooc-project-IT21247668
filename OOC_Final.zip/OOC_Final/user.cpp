#include "user.h"
user::user()
{
	cout << "contractor call" << endl;
}
void user::setDetails(int uId, string uName, string umail, string uPass)
{
	id = uId;
	name = uName;
	email = umail;
	password = uPass;
}
void user::dispayUser()
{
	cout << "ID:" << id << endl;
	cout << "Name:" << name << endl;
	cout << "Email:" << email << endl;
	cout << "Password:" << password << endl;
}
