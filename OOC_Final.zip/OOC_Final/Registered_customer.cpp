#include "registeredCustomer.h"
registeredCustomer::registeredCustomer()
{
	cout << "Default Constructor of registeredCustomer called" << endl;
}
registeredCustomer::registeredCustomer(int cId, string cAddress, double cprice,
	int qty)
{
	customerId = cId;
	address = cAddress;

}
void registeredCustomer::setprice(double cprice)
{
	price = cprice;
}
void registeredCustomer::setquantity(int qty)
{
	quantity = qty;
}
double registeredCustomer::calPrice()
{
	cout << "payment:" << quantity * price << endl;
}
registeredCustomer::~registeredCustomer()
{
	cout << "Destructor of registeredCustomer called" << endl;
}